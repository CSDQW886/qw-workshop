# -*- coding: utf-8 -*-
import io

R = '/storage/emulated/0/ai/QW-Handover-v17/04-source/qw-fromscratch/'
URL = 'https://github.com/weilund/we-workshop/blob/main/README.md'
LINK = ('<a href="' + URL + '" target="_blank" rel="noopener" '
        'onclick="try{if(window.QW&amp;&amp;QW.openUrl){QW.openUrl(&#39;' + URL + '&#39;);return false}}catch(e){}" '
        'style="color:#6fa8ff;text-decoration:underline;word-break:break-all">' + URL + '</a>')

p = R + 'assets/index.html'
s = io.open(p, encoding='utf-8').read()

pairs = [
    ('本应用参考开源项目 <b>we-workshop</b>（作者 <b>weilund</b>）的功能思路<b>重新实现</b>',
     '本项目<b>基于</b> ' + LINK + ' <b>开发</b>'),
    ('参考开源 <b>we-workshop</b>（作者 <b>weilund</b>）重新实现，与原作者无隶属关系。',
     '基于 ' + LINK + ' 开发，与原作者无隶属关系。'),
    ('QW 工坊 · 参考开源 we-workshop（weilund）重新实现 · AI 辅助开发',
     'QW 工坊 · 基于 github.com/weilund/we-workshop 开发 · AI 辅助开发'),
]

for old, new in pairs:
    n = s.count(old)
    print('HIT', n, old[:30])
    if n:
        s = s.replace(old, new)

io.open(p, 'w', encoding='utf-8').write(s)
print('HTML left 参考 =', s.count('参考'))
print('HTML 基于 count =', s.count('基于'))

pm = R + 'README.md'
m = io.open(pm, encoding='utf-8').read()
old = '参考开源项目 [we-workshop](https://github.com/weilund/we-workshop)（作者 **weilund**）的功能思路重新实现，与原作者无隶属关系。'
new = '**基于** [we-workshop](' + URL + ') **开发**，与原作者无隶属关系。'
print('README HIT', m.count(old))
m = m.replace(old, new)
io.open(pm, 'w', encoding='utf-8').write(m)
print('README left 参考 =', m.count('参考'))
