# -*- coding: utf-8 -*-
"""v1.0.1-r20 出包：仅替换前端资源 + 修复版基座 dex（不含 classes7 media dex）"""
import os
import shutil
import subprocess
import sys
import zipfile

ROOT = '/storage/emulated/0/ai/QW-Handover-v17'
PROJ = os.path.join(ROOT, '04-source/qw-fromscratch')
BASE = os.path.join(PROJ, 'build/qw-u127.apk')
OLD = '/storage/emulated/0/ai/_archive/legacy/legacy-apk/WE-Workshop-v0.6.0-preview2.apk'
NEWDEX = '/storage/emulated/0/ai/_wd/classes_patched.dex'
MERGED = os.path.join(PROJ, 'build/qw-merged127.apk')
ALIGNED = os.path.join(PROJ, 'build/qw-a127.apk')
SIGNED = os.path.join(PROJ, 'build/qw-s127.apk')
KS = os.path.join(ROOT, '06-env/we.keystore')


def merge():
    zo = zipfile.ZipFile(OLD)
    olddex = sorted(
        [n for n in zo.namelist() if n.startswith('classes') and n.endswith('.dex')],
        key=lambda n: 0 if n == 'classes.dex' else int(n[7:-4]),
    )
    print('old dex order:', olddex)
    replaced = open(NEWDEX, 'rb').read()
    print('rebuilt dex:', len(replaced))

    zi = zipfile.ZipFile(BASE)
    with zipfile.ZipFile(MERGED, 'w') as zw:
        for item in zi.infolist():
            z = zipfile.ZipInfo(item.filename, item.date_time)
            z.external_attr = item.external_attr
            z.compress_type = (
                zipfile.ZIP_STORED
                if item.filename.endswith(('.png', '.jpg', '.jpeg', '.arsc'))
                else zipfile.ZIP_DEFLATED
            )
            with zi.open(item) as src, zw.open(z, 'w') as dst:
                shutil.copyfileobj(src, dst, 65536)

        for i, name in enumerate(olddex):
            data = replaced if i == 0 else zo.read(name)
            tag = 'REBUILT' if i == 0 else 'raw'
            zw.writestr('classes%d.dex' % (i + 2), data, compress_type=zipfile.ZIP_DEFLATED)
            print('  classes%d.dex <- %s %s (%d bytes)' % (i + 2, name, tag, len(data)))

        libs = [n for n in zo.namelist() if n.startswith('lib/') and n.endswith('.so')]
        for ln in libs:
            z = zipfile.ZipInfo(ln, zo.getinfo(ln).date_time)
            z.external_attr = 0o644 << 16
            z.compress_type = zipfile.ZIP_STORED
            zw.writestr(z, zo.read(ln))
        print('libs added:', len(libs))

        for extra in ['assets/PublicSuffixDatabase.list']:
            if extra in zo.namelist():
                zw.writestr(extra, zo.read(extra), compress_type=zipfile.ZIP_DEFLATED)

    print('merged', os.path.getsize(MERGED))


def run(cmd):
    print('+', ' '.join(cmd))
    rc = subprocess.call(cmd)
    if rc:
        sys.exit('命令失败 rc=%d: %s' % (rc, cmd[0]))


if __name__ == '__main__':
    if not os.path.exists(BASE):
        sys.exit('缺少 %s，先跑 apktool b' % BASE)
    if not os.path.exists(NEWDEX):
        sys.exit('缺少 %s' % NEWDEX)
    merge()
    run(['zipalign', '-f', '-p', '4', MERGED, ALIGNED])
    run([
        'apksigner', 'sign', '--ks', KS, '--ks-key-alias', 'we',
        '--ks-pass', 'pass:123456', '--key-pass', 'pass:123456',
        '--out', SIGNED, ALIGNED,
    ])
    run(['apksigner', 'verify', SIGNED])
    print('signed', SIGNED, os.path.getsize(SIGNED))